package com.example.scarx.idcardreader;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.zkteco.android.IDReader.IDPhotoHelper;
import com.zkteco.android.IDReader.WLTService;
import com.zkteco.android.biometric.core.device.ParameterHelper;
import com.zkteco.android.biometric.core.device.TransportType;
import com.zkteco.android.biometric.core.utils.LogHelper;
import com.zkteco.android.biometric.module.idcard.IDCardReader;
import com.zkteco.android.biometric.module.idcard.IDCardReaderFactory;
import com.zkteco.android.biometric.module.idcard.exception.IDCardReaderException;
import com.zkteco.android.biometric.module.idcard.meta.IDCardInfo;
import com.zkteco.android.biometric.module.idcard.meta.IDPRPCardInfo;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final int VID = 1024;    //IDR VID
    private static final int PID = 50010;     //IDR PID
    private IDCardReader idCardReader = null;
    private TextView textView = null;
    private ImageView imageView = null;
    private boolean bopen = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        textView = (TextView) findViewById(R.id.textView);
        imageView = (ImageView)findViewById(R.id.imageView);
        startIDCardReader();
    }

    public Context getContext()
    {
        return this.getApplicationContext();
    }

    private void startIDCardReader() {
        // Define output log level
        LogHelper.setLevel(Log.VERBOSE);
        // Start fingerprint sensor
        Map idrparams = new HashMap();
        idrparams.put(ParameterHelper.PARAM_KEY_VID, VID);
        idrparams.put(ParameterHelper.PARAM_KEY_PID, PID);
        idCardReader = IDCardReaderFactory.createIDCardReader(this, TransportType.USB, idrparams);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Destroy fingerprint sensor when it's not used
        IDCardReaderFactory.destroy(idCardReader);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void OnBnOpen(View view)
    {
        try {
            if (bopen) return;
            idCardReader.open(0);
            bopen = true;
            textView.setText("连接设备成功");
        }
        catch (IDCardReaderException e)
        {
            textView.setText("关闭设备成功");
            LogHelper.d("连接设备失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }
    }

    public void OnBnClose(View view)
    {
        try {
            if (bopen)
            {
                idCardReader.close(0);
                bopen = false;
            }
            textView.setText("关闭设备成功");
        }
        catch (IDCardReaderException e)
        {
            textView.setText("关闭设备失败");
            LogHelper.d("关闭设备失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }
    }

    public void OnBnGetSamID(View view)
    {
        try {
            if (!bopen) {
                textView.setText("请先连接设备");
            }
            String samid = idCardReader.getSAMID(0);
            textView.setText("获取SAM编号成功："+ samid);
        }
        catch (IDCardReaderException e)
        {
            textView.setText("获取SAM编号失败");
            LogHelper.d("获取SAM模块失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }
    }

    public void OnBnFind(View view)
    {
        try {
            if (!bopen) {
                textView.setText("请先连接设备");
            }
            idCardReader.findCard(0);
            textView.setText("寻卡成功");
        }
        catch (IDCardReaderException e)
        {
            textView.setText("寻卡失败");
            LogHelper.d("寻卡失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }
    }

    public void OnBnSelect(View view)
    {
        try {
            if (!bopen) {
                textView.setText("请先连接设备");
            }
            idCardReader.selectCard(0);
            textView.setText("选卡成功");
        }
        catch (IDCardReaderException e)
        {
            textView.setText("选卡失败");
            LogHelper.d("选卡失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }
    }

    private void showMessage(String string)
    {
        new AlertDialog.Builder(this)
                .setTitle("提示")
                .setMessage(string)
                .setPositiveButton( "确定" ,
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialoginterface, int i){
                            }
                        }).show();
    }

    private  int index = 0;
    public   String printHexString( byte[] b) {
        String a = "";
        for (int i = 0; i < 1024; i++) {
            String hex = Integer.toHexString(b[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }

            a = a+hex;
        }

        return a;
    }

    public void Authenticate()
    {
        try {
            idCardReader.findCard(0);
            idCardReader.selectCard(0);
        } catch (IDCardReaderException e) {
            e.printStackTrace();
        }
    }

    public void OnBnRead(View view)
    {
        try {
            if (!bopen) {
                textView.setText("请先连接设备");
            }
            long nTickStart = System.currentTimeMillis();
            Authenticate();
            //IDCardInfo idCardInfo = new IDCardInfo();
            //boolean ret = idCardReader.readCard(0, 1, idCardInfo);
            int ret = idCardReader.readCardEx(0, 1);
            long nTickRead = System.currentTimeMillis();
            if (1 == ret)
            {
                IDCardInfo idCardInfo = idCardReader.getLastIDCardInfo();
                textView.setText("timeSet:"+ (nTickRead-nTickStart) + "姓名：" + idCardInfo.getName() + "，民族：" + idCardInfo.getNation() + "，住址：" + idCardInfo.getAddress() + ",身份证号：" + idCardInfo.getId());
                if (idCardInfo.getPhotolength() > 0){
                    byte[] buf = new byte[WLTService.imgLength];
                    nTickStart = System.currentTimeMillis();
                    if(1 == WLTService.wlt2Bmp(idCardInfo.getPhoto(), buf))
                    {
                        System.out.println("timeSet decode photo, use time:" + (System.currentTimeMillis() - nTickStart));
                        imageView.setImageBitmap(IDPhotoHelper.Bgr2Bitmap(buf));
                    }
                }
            }
            else if (2 == ret)
            {
                IDPRPCardInfo idprpCardInfo = idCardReader.getLastPRPIDCardInfo();
                textView.setText("timeSet:"+ (nTickRead-nTickStart) + "英文名：" + idprpCardInfo.getEnName() + "，中文名：" + idprpCardInfo.getCnName() +
                        "，国家：" + idprpCardInfo.getCountry() +  ",证件号：" + idprpCardInfo.getId());
                if (idprpCardInfo.getPhotolength() > 0){
                    byte[] buf = new byte[WLTService.imgLength];
                    nTickStart = System.currentTimeMillis();
                    if(1 == WLTService.wlt2Bmp(idprpCardInfo.getPhoto(), buf))
                    {
                        System.out.println("timeSet decode photo, use time:" + (System.currentTimeMillis() - nTickStart));
                        imageView.setImageBitmap(IDPhotoHelper.Bgr2Bitmap(buf));
                    }
                }
            }
        }
        catch (IDCardReaderException e)
        {
            textView.setText("读卡失败");
            LogHelper.d("读卡失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }
    }
}
